package prueba;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class CarGame extends JFrame implements KeyListener {

    private Car car;
    private Road road;
    private Background background;
    private final int roadTop = 300;  // Ajustamos la posición superior de la carretera
    private final int roadBottom = 500;  // Ajustamos la posición inferior de la carretera

    public CarGame() {
        this.car = new Car(100, roadTop + 50, 100, 60, "player.png");
        this.road = new Road(0, roadTop, 800, 200, "carretera.jpg");
        this.background = new Background(0, 0, 800, 300, "edad_prehis.jpg");  // Inicialmente con una imagen

        setTitle("Car Game");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        addKeyListener(this);

        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                background.draw(g);
                road.draw(g);
                car.draw(g);
            }
        };

        add(panel);

        Timer timer = new Timer(100, e -> {
            background.move();
            road.move();
            repaint();
        });
        timer.start();

        setVisible(true);
    }

    public void changeBackground(String imagePath) {
        background.loadImage(imagePath);
        repaint();
    }

    public static void main(String[] args) {
        CarGame game = new CarGame();
        
        // Aquí puedes cambiar el fondo con una acción, por ejemplo, con un botón o temporizador
        // game.changeBackground("edad_antigua.jpg");
        // game.changeBackground("edad_media.jpg");
        // game.changeBackground("edad_moderna.jpg");
    }

    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyPressed(KeyEvent e) {
        int key = e.getKeyCode();

        switch (key) {
            case KeyEvent.VK_UP:
                car.moveUp(roadTop);
                break;
            case KeyEvent.VK_DOWN:
                car.moveDown(roadBottom);
                break;
            case KeyEvent.VK_LEFT:
                car.moveLeft();
                break;
            case KeyEvent.VK_RIGHT:
                car.moveRight(getWidth());
                break;
        }

        repaint();
    }

    @Override
    public void keyReleased(KeyEvent e) {}
}
