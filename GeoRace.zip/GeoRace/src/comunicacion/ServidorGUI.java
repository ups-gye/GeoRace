
package comunicacion;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.*;

public class ServidorGUI extends JFrame {

    private JTextArea textArea;
    private ServerSocket serverSocket;
    private Socket clientSocket;
    private BufferedReader in;

    public ServidorGUI() {
        setTitle("Servidor");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        textArea = new JTextArea();
        textArea.setEditable(false);
        add(new JScrollPane(textArea), BorderLayout.CENTER);

        JButton startButton = new JButton("Iniciar Servidor");
        startButton.addActionListener(e -> startServer());
        add(startButton, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void startServer() {
        new Thread(() -> {
            try {
                serverSocket = new ServerSocket(12345);
                textArea.append("Servidor escuchando en el puerto 12345...\n");
                clientSocket = serverSocket.accept();
                textArea.append("Cliente conectado!\n");

                in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    textArea.append("Nombre recibido: " + inputLine + "\n");
                }
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error en el servidor: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }).start();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ServidorGUI::new);
    }
}
